<template>
    <div class="fillcontain">
        newMember
    </div>
</template>

<script>
    export default {
    	
    }
</script>

<style lang="less">
	@import '../style/mixin';
</style>
