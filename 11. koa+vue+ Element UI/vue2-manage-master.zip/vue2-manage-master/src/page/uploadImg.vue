<template>
    <div class="fillcontain">
        uploadImg
    </div>
</template>

<script>
    export default {
    	
    }
</script>

<style lang="less">
	@import '../style/mixin';
</style>
