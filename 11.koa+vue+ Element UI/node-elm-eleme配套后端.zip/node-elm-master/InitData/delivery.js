export default {
color: "57A9FF",
id: 1,
is_solid: true,
text: "蜂鸟专送"
}