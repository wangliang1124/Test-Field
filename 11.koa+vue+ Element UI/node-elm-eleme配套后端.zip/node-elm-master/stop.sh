#stop server

npm stop