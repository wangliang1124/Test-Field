#start server

npm start